import React from 'react';
import '../App.css';

function Blog() {
  return (
    <div className="App">
    <div className='blogg'>
        <header className="header">
          <h1>Blogg</h1>
        </header>

        <div className='content'>
          
          <h2>Lorem Ipsum</h2>
          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, 
          <br/>
          <br/>
          <h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</h3>
          <button className='button'>Trykk her</button>   
        </div>
    </div>
  </div>
  );
}

export default Blog;
