import React from 'react';
import '../../App.css';

function TeamMember() {
  return (
    <div className='teamMember'>
      <img/>
      <div>Navn</div>
      <div>Rolle</div>
    </div>
  );
}

export default TeamMember;
